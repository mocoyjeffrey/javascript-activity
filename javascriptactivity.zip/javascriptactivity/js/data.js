var students = { "MIT" : [
{ "name" : "Reymar", "gender" : "Male", "action" :"view resume"},
{ "name" : "Cindy", "gender" : "Female" , "action" : "view resume"},
{ "name" : "Kevin", "gender" : "Male", "action" : "view resume" },
{ "name" : "Dan", "gender" : "Male" , "action" : "view resume"},
{ "name" : "Ed", "gender" : "Male" , "action" : "view resume"},
{ "name" : "Glester", "gender" : "Male" , "action" : "view resume"},
{ "name" : "Jeffrey", "gender" : "Male" ,"action" : "view resume" }
]
}  

var htmlStudents = "<thead><tr><td>Name</td><td>Gender</td><td>Action</td></tr></thead>";

htmlStudents+="<tbody>";
for(i=0;i<students.MIT.length;i++)
{
//htmlStudents+="<td>";
//htmlStudents+="<table border='1' width=100 >";
htmlStudents+="<tr><td width=33>"+ students.MIT[i].name+"</td><td width=33>"+ students.MIT[i].gender +"</td><td width=33>"+ students.MIT[i].action +"</td></tr>";
//htmlStudents+="<tr><td><b>Gender</b></td><td width=50>"+ students.MIT[i].gender +"</td></tr>";
//htmlStudents+="</table>";
//htmlStudents+="</td>";
}
htmlStudents += "<tr>";

var _table2 = document.getElementById('myTable2');	
_table2.innerHTML = htmlStudents;