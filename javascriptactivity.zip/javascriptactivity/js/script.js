var _title = document.getElementById('myTitle');
_title.innerHTML = "MIT Resume";

var _subtitle = document.getElementById('mySubTitle');
_subtitle.innerHTML = "First Table";

var _subtitle = document.getElementById('title2');
_subtitle.innerHTML = "Student Profile";

var _table = document.getElementById('myTable');
var row = 3;
var col = 2;
var arrNames = ['Reymar', 'Cindy', 'Kevin'];
var arrGender = ['Male', 'Female', 'Male'];
var index = 0;
var html = "<thead><tr><th>Name</th><th>Gender</th></tr></thead>";
html += "<tbody>";
for(x=0;x<row;x++){
  html+="<tr>";
  {
  html+="<td>"+arrNames[index]+"</td>";
  html+="<td>"+arrGender[index]+"</td>";
  }
  html+="</tr>";
  index++;
}
html += "</tbody>";
_table.innerHTML = html;